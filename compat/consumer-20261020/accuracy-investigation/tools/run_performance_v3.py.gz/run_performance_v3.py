"""Serialized ABBA workload comparison of exact identified public baseline/candidate wheels."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
from zipfile import ZipFile
work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate';old=work.parent/'candidate-20261020'
baseline=old/'comparison-baseline-artifact/gr_tdigest-0.2.4-cp310-abi3-manylinux_2_28_x86_64.whl'
candidate=work/'artifacts-v3/gr_tdigest-0.2.5.dev2026102003-cp310-abi3-manylinux_2_28_x86_64.whl'
out=work/'results/performance-v3';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(RAYON_NUM_THREADS='1',POLARS_MAX_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
basevenv=work/'performance-baseline-v3'
for name,cmd in [('venv',['uv','venv','--offline','--python','3.12',basevenv]),('install',['uv','pip','install','--offline','--python',basevenv/'bin/python','numpy==2.5.4','polars==2.0.0',baseline])]:
 with (out/f'setup-{name}.log').open('w') as f:subprocess.run([str(x) for x in cmd],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
manifest={'source_sha':{'baseline':'1451f94c4d809dd43d851b91c7c777ad3c3ff2f3','candidate':'60b295140d5eed81df24a8aed05f89767646c7d8'},'wheels':{},'benchmark_sha256':hashlib.sha256((root/'scripts/consumer_benchmark.py').read_bytes()).hexdigest(),'protocol':'Fresh subprocess per scenario, baseline/candidate/candidate/baseline; fixed Rayon1/Polars4/BLAS1/OMP1; no task-owned heavy builds or other timings overlap. Light evidence orchestration only. Descriptive measured comparison, not a release acceptance gate.','private_0.1.9_0.1.11':False}
for label,wheel in [('baseline',baseline),('candidate',candidate)]:
 with ZipFile(wheel) as archive:loaded=hashlib.sha256(archive.read('gr_tdigest/_gr_tdigest.abi3.so')).hexdigest()
 manifest['wheels'][label]={'path':str(wheel),'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'native_sha256':loaded}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=[]
for scenario in ('columns16','columns64','columns128','fanin40','stream','bridge','concurrency'):
 for index,label in enumerate(('baseline','candidate','candidate','baseline')):
  python=(basevenv if label=='baseline' else work/'artifact-qa-v3')/'bin/python'
  target=out/f'{scenario}-{index}-{label}.json'
  command=[str(python),'-I',str(root/'scripts/consumer_benchmark.py'),'--source-sha',manifest['source_sha'][label],'--output',str(target),'--worker',scenario]
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/f'{scenario}-{index}-{label}.log').open('w') as log:result=subprocess.run(command,cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT)
  row=dict(scenario=scenario,position=index,label=label,command=command,started_utc=started,exit_code=result.returncode)
  rows.append(row);tmp=out/'ledger.tmp';tmp.write_text(json.dumps(rows,indent=2)+'\n');tmp.replace(out/'ledger.json')
  assert result.returncode==0,row
  data=json.loads(target.read_text());assert data['native_sha256']==manifest['wheels'][label]['native_sha256']
  assert data['numpy']=='2.5.4' and data['polars']=='2.0.0'
  print(scenario,index,label,'PASS',flush=True)
print('COMPLETED',flush=True)
