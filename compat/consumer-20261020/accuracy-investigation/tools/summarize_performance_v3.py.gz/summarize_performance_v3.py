"""Summarize the completed exact-wheel ABBA comparison without a performance pass gate."""
import hashlib
import json
from pathlib import Path
import statistics
work=Path(__file__).resolve().parent
out=work/'results/performance-v3'
inputs=json.loads((out/'inputs.json').read_text())
ledger=json.loads((out/'ledger.json').read_text())
assert len(ledger)==28 and all(row['exit_code']==0 for row in ledger)
def quantile(values,p):
 v=sorted(values);index=(len(v)-1)*p;lo=int(index);hi=min(lo+1,len(v)-1)
 return v[lo]+(v[hi]-v[lo])*(index-lo)
result={**inputs,'status':'COMPLETED_MEASURED_COMPARISON_NOT_AN_ACCEPTANCE_GATE','scenarios':{},'concurrency':[]}
for scenario in ('columns16','columns64','columns128','fanin40','stream','bridge','concurrency'):
 rows={label:[json.loads((out/f'{scenario}-{i}-{label}.json').read_text()) for i in ([0,3] if label=='baseline' else [1,2])] for label in ['baseline','candidate']}
 summary={}
 for label,data in rows.items():
  assert all(x['native_sha256']==inputs['wheels'][label]['native_sha256'] for x in data)
  summary[label]={'native_sha256':data[0]['native_sha256'],'peak_process_rss_kib_range':[min(x['peak_process_rss_kib'] for x in data),max(x['peak_process_rss_kib'] for x in data)]}
  for name,value in data[0].items():
   if isinstance(value,dict) and 'seconds' in value:
    samples=[s for row in data for s in row[name]['seconds']]
    summary[label][name]={'median_seconds':statistics.median(samples),'p95_seconds':quantile(samples,.95),'p99_seconds':quantile(samples,.99),'samples':len(samples)}
 summary['candidate_time_change_percent']={name:100*(summary['candidate'][name]['median_seconds']/value['median_seconds']-1) for name,value in summary['baseline'].items() if isinstance(value,dict) and 'median_seconds' in value}
 result['scenarios'][scenario]=summary
 if scenario=='concurrency':
  for workers in [1,2,4,8,16]:
   row={'workers':workers}
   for label,data in rows.items():
    matches=[next(r for r in d['rows'] if r['workers']==workers) for d in data]
    batches=[s for r in matches for s in r['batch_seconds']]
    elapsed=statistics.median(batches)
    row[label]={'batch_median_seconds':elapsed,'batch_samples':len(batches),'values_per_second':64*32768/elapsed,'submission_to_completion_p95_seconds_per_run':[r['submission_to_completion_p95_seconds'] for r in matches],'submission_to_completion_p99_seconds_per_run':[r['submission_to_completion_p99_seconds'] for r in matches]}
   result['concurrency'].append(row)
result['sample_limit']='Only six pooled timings for training/merge/stream; 24 for repeated queries/bridge; six batches per worker count. Sample p95/p99 are descriptive and not reliable population-tail guarantees. Desktop services were active, no task-owned heavy build/timing overlapped.'
result['files']={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()}
(work/'results/performance-summary-v3.json').write_text(json.dumps(result,indent=2)+'\n')
for name,data in result['scenarios'].items():print(name,data['candidate_time_change_percent'])
for row in result['concurrency']:print('workers',row['workers'],'candidatevalues/s',row['candidate']['values_per_second'])
