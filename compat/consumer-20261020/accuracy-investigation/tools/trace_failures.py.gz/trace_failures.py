"""Trace represented mass across actual merges and compare probes with raw truth."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import gr_tdigest as gr
import gr_tdigest._gr_tdigest as native
work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
spec=importlib.util.spec_from_file_location('quality_trace',root/'scripts/quality_suite.py')
q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
module=Path(native.__file__)
receipt={'source_inputs_sha256':q.source_hashes(),'native_sha256':q.sha(module),'runner_sha256':q.sha(Path(__file__)),'traces':[]}
source={name:raw for name,kind,raw in q.datasets(root/'tests/quality/data','extended')}
for dataset in ['synthetic/bimodal','synthetic/signed_scale']:
    data=np.array(source[dataset],dtype=np.float64)[::-1].copy()
    pieces=np.array_split(data,40)
    for cap in [32,64,200,1000]:
        stages=[];acc=None;observed=[]
        for index,piece in enumerate(pieces):
            observed.extend(piece.tolist())
            part=gr.TDigest.from_array(piece,max_size=cap,precision='f64')
            acc=part if acc is None else gr.TDigest.merge_all([acc,part])
            truth=q.Exact(observed)
            blob=acc.to_bytes();header=blob[6];stride=17
            assert len(blob)==header+stride*len(acc)
            kinds=[blob[header+stride*(i+1)-1] for i in range(len(acc))]
            assert all(k in [0,1] for k in kinds)
            mixed=[w/acc.count for w,k in zip(acc.weights,kinds) if k==1]
            probes=sorted(set(truth.quantile(p) for p in q.Q))
            worst=max(probes,key=lambda x:abs(acc.cdf(x)-truth.cdf(x)))
            stages.append({'stage':index+1,'observations':len(observed),'centroids':len(acc),'max_mixed_mass_fraction':max(mixed,default=0.),'probe':worst,'estimated_cdf':acc.cdf(worst),'truth_cdf':truth.cdf(worst),'cdf_abs_error':abs(acc.cdf(worst)-truth.cdf(worst)),'cdf_at_zero':acc.cdf(0.),'truth_cdf_at_zero':truth.cdf(0.),'median':acc.median()})
        truth=q.Exact(data.tolist())
        negative=max(x for x in truth.values if x<0)
        positive=min(x for x in truth.values if x>0)
        gap_centroids=[{'mean':float(m),'weight':float(w),'mass_fraction':float(w)/acc.count,'mixed':kind==1} for m,w,kind in zip(acc.means,acc.weights,kinds) if negative<m<positive]
        receipt['traces'].append({'dataset':dataset,'precision':'f64','capacity':cap,'path':'reverse/left40','input_sha256':hashlib.sha256(data.tobytes()).hexdigest(),'raw_empty_interval':[negative,positive],'centroids_in_raw_empty_interval':gap_centroids,'final_full_state_sha256':hashlib.sha256(acc.to_bytes()).hexdigest(),'final_means':acc.means.tolist(),'final_weights':acc.weights.tolist(),'final_kinds':kinds,'stages':stages})
q.verify_inputs_unchanged(receipt,module)
receipt['input_status']='UNCHANGED'
q.atomic_json(work/'results/merge-traces.json',receipt)
print(json.dumps([{'dataset':r['dataset'],'capacity':r['capacity'],'max_mixed_mass':r['stages'][-1]['max_mixed_mass_fraction'],'cdf_error':r['stages'][-1]['cdf_abs_error'],'zero_error':r['stages'][-1]['cdf_at_zero']-r['stages'][-1]['truth_cdf_at_zero'],'gap_centroids':r['centroids_in_raw_empty_interval']} for r in receipt['traces']],indent=2))
