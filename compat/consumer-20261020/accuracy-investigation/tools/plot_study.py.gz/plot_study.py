import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
work=Path(__file__).resolve().parent
out=work/'report';out.mkdir(exist_ok=True)
old=json.loads((work/'results/capacity-study.json').read_text())
new=json.loads((work/'results/holdouts.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(12.5,4.9))
for ax,(metric,title) in zip(axes,[('cdf_max','Worst cumulative share error'),('tail_rank_max','Worst tail rank error')]):
    for data,scale,label,color,style in [(old,'k2','K2 · established cases','#1457a6','-'),(new,'k2','K2 · additional shapes','#1457a6','--'),(old,'quad','Quad · established cases','#cf6c22','-'),(new,'quad','Quad · additional shapes','#cf6c22','--')]:
        caps=sorted(int(k.split('/')[1]) for k in data['summary'] if k.startswith(scale+'/'))
        errors=[100*data['summary'][f'{scale}/{cap}']['worst_errors'][metric] for cap in caps]
        ax.plot(caps,errors,style,marker='o',ms=4,color=color,label=label,lw=1.8)
    ax.set_xscale('log');ax.set_xticks([16,32,64,128,200,512,1000],['16','32','64','128','200','512','1,000'])
    ax.set_title(title,loc='left',pad=12);ax.set_xlabel('Maximum summary size');ax.set_ylabel('Percentage points');ax.grid(axis='y',color='#dce2e9',lw=.6)
    ax.set_ylim(bottom=-.02)
axes[0].legend(frameon=False,fontsize=9,loc='upper right')
fig.suptitle('Smaller summaries lose accuracy; changing the scale has tradeoffs',x=.06,ha='left',fontsize=15,fontweight='bold')
fig.text(.06,.04,'Measured on 21 established data columns/shapes and 12 additional deterministic shapes, both precisions and 40-way merges.\nWorst observed errors; profiles share data. These curves are not universal guarantees. Tail error uses the fixed sampled probabilities.',fontsize=9,color='#485365')
fig.subplots_adjust(left=.07,right=.98,top=.80,bottom=.22,wspace=.30)
for ext in ['png','svg']:fig.savefig(out/f'accuracy-capacity.{ext}',dpi=180)
plt.close(fig)
fig,ax=plt.subplots(figsize=(9.5,4.9))
populations=[([0,4.5,8,10],[1,84,14,1],'Population A','#1457a6'),([0,2,5.5,10],[1,14,84,1],'Population B','#a34d99')]
for values,weights,label,color in populations:
    xs=[-.3];ys=[0.];mass=0
    for value,weight in zip(values,weights):
        xs.extend([value,value]);ys.extend([mass/100,(mass+weight)/100]);mass+=weight
    xs.append(10.3);ys.append(1.)
    ax.plot(xs,ys,label=label,lw=2,color=color)
    ax.scatter([5],[.85 if label.endswith('A') else .15],color=color,zorder=4,s=36)
ax.plot([0,10],[0,1],color='#5b6b76',lw=1.7,ls='--',label='Shared one-group estimate')
ax.axvline(5,color='#c4cbd2',lw=.8)
ax.annotate('85% below 5',(5,.85),xytext=(5.4,.87),color='#1457a6',fontsize=10)
ax.annotate('15% below 5',(5,.15),xytext=(5.4,.12),color='#a34d99',fontsize=10)
ax.set(xlim=(-.3,10.3),ylim=(-.02,1.02),xlabel='Value',ylabel='Cumulative share')
ax.set_title('Identical saved state can hide different populations',loc='left',pad=18,fontsize=15)
ax.legend(loc='upper left',frameon=False);ax.grid(axis='y',color='#e3e7ed')
fig.text(.085,.04,'Both compress to one mixed group: mean 5, mass 100, sum 500, minimum 0, maximum 10.\nTheir full saved bytes are identical. The example illustrates lost information; it does not prove size 32 cannot improve.',fontsize=9,color='#485365')
fig.subplots_adjust(left=.085,right=.98,top=.84,bottom=.23)
for ext in ['png','svg']:fig.savefig(out/f'information-loss.{ext}',dpi=180)
plt.close(fig)
meta={'matplotlib':matplotlib.__version__,'numpy':np.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputs':{str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [work/'results/capacity-study.json',work/'results/holdouts.json',work/'results/information-loss.json']},'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*') if p.suffix in ['.png','.svg']}}
(out/'figures.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
