import gr.tdigest.TDigest;import java.util.*;
public class CrossArtifact {
 public static void main(String[] args) {
  TDigest d=args[0].equals("restore") ? TDigest.fromBytes(Base64.getDecoder().decode(args[1])) :
   TDigest.builder().maxSize(1000).precision(TDigest.Precision.valueOf(args[0])).buildWeighted(new double[]{0,0,1,5,10},new double[]{.25,.75,2,3,4});
  try {System.out.println(Base64.getEncoder().encodeToString(d.toBytes())+"|"+
    Arrays.toString(d.cdf(new double[]{-1,0,.5,1,3,5,10,11}))+"|"+
    Arrays.toString(d.quantile(new double[]{0,.1,.5,.9,1})));}finally{d.close();}
 }
}
