"""Source-bound diagnostic operating-envelope study; never an acceptance waiver."""
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import numpy as np
import gr_tdigest as gr
import gr_tdigest._gr_tdigest as native

work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
spec=importlib.util.spec_from_file_location('quality_study',root/'scripts/quality_suite.py')
q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
base_source=(work/'compressor-base.rs').read_bytes()
assert (root/'src/tdigest/compressor.rs').read_bytes()==base_source
source_before=q.source_hashes()
module=Path(native.__file__)
native_hash=q.sha(module)
protocol={
    'kind':'diagnostic configurations and capacities; new cases, not a replacement frozen baseline or universal guarantee',
    'base_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'k2_capacities':[16,32,64,128,200,512,1000],
    'alternate_scales':{'quad':[32,200,1000],'k1':[32,200,1000]},
    'precisions':['f32','f64'],'paths':['bulk','left40','balanced40'],
    'orders':['natural','reverse'],'data':'same full21columns/distributions as the extended suite',
    'reference':'unchanged independent exact reference/scoring/invariants from scripts/quality_suite.py',
    'diagnostic_envelope':'existing0.1(rank_max/CDF) for size<=32;0.05above32, applied diagnostically to additional capacities; not a new acceptance policy',
    'original_comparison':'K2capacities200/1000; tune original count to actual modern logical-byte budget without consulting accuracy; retain90%-100% eligibility rule',
}
receipt={'protocol':protocol,'protocol_sha256':hashlib.sha256(json.dumps(protocol,sort_keys=True).encode()).hexdigest(),'source_inputs_sha256':source_before,'native_sha256':native_hash,'runner_sha256':q.sha(Path(__file__)),'data_manifest_sha256':q.sha(root/'tests/quality/data/manifest.json'),'python':sys.version,'numpy':np.__version__,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_status':'NOT_VERIFIED','rows':[]}
target=work/'results/capacity-study.json'
def save(): q.atomic_json(target,receipt)
save()
for dataset,kind,raw in q.datasets(root/'tests/quality/data','extended'):
    for precision in ['f32','f64']:
        values=np.array(raw,dtype=np.float32 if precision=='f32' else np.float64)
        exact=q.Exact(values.tolist())
        for scale,caps in [('k2',protocol['k2_capacities']),*protocol['alternate_scales'].items()]:
            q.PROTOCOL['modern']['scale']=scale
            for cap in caps:
                for order in ['natural','reverse']:
                    data=values if order=='natural' else values[::-1].copy()
                    for route in protocol['paths']:
                        row={'id':f'{dataset}/{precision}/size{cap}/{order}/{route}/{scale}','dataset':dataset,'kind':kind,'precision':precision,'max_size':cap,'order':order,'path':route,'scale':scale,'n':len(data)}
                        try:
                            digest=q.build(data,precision,cap,'modern',route)
                            row['modern']=q.score(digest,exact,True)
                            row['modern_state']={'centroids':len(digest),'field_bytes':len(digest)*(data.dtype.itemsize+9),'wire_bytes':len(digest.to_bytes()),'max_centroid_mass_fraction':float(np.max(digest.weights))/digest.count,**q.invariants(digest,data,precision,True)}
                            bound=.1 if cap<=32 else .05
                            row['diagnostic_envelope_failures']=[k for k in ['rank_max','cdf_max'] if row['modern'][k]>bound]
                            if scale=='k2' and cap in [200,1000]:
                                original,delta,size,trace=q.match_original(data,precision,row['modern_state']['field_bytes'],route)
                                row['original']=q.score(original,exact,False)
                                row['original_state']={'centroids':len(original),'delta':delta,'field_bytes':size,'selection_trace':trace,**q.invariants(original,data,precision,False)}
                                row['comparison_eligible']=.9<=size/row['modern_state']['field_bytes']<=1
                        except Exception as e:
                            row['error']=f'{type(e).__name__}: {e}'
                        receipt['rows'].append(row)
    print(dataset,'completed',flush=True);save()
q.verify_inputs_unchanged(receipt,module)
receipt['input_status']='UNCHANGED'
receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['profiles']=len(receipt['rows'])
receipt['errors']=sum('error' in row for row in receipt['rows'])
summary={}
for scale in ['k2','quad','k1']:
    for cap in sorted({r['max_size'] for r in receipt['rows'] if r['scale']==scale}):
        selected=[r for r in receipt['rows'] if r['scale']==scale and r['max_size']==cap]
        summary[f'{scale}/{cap}']={'profiles':len(selected),'errors':sum('error' in r for r in selected),'envelope_failed_profiles':sum(bool(r.get('diagnostic_envelope_failures')) for r in selected),'worst_errors':{metric:max(r['modern'][metric] for r in selected if 'modern' in r) for metric in q.GATED},'largest_centroid_fraction':max(r['modern_state']['max_centroid_mass_fraction'] for r in selected if 'modern_state' in r)}
receipt['summary']=summary
save()
# Exact information-loss example, not a passing approximate-accuracy control.
examples=[]
for precision in ['f32','f64']:
    a=gr.TDigest.from_array([0.,4.5,8.,10.],weights=[1.,84.,14.,1.],max_size=1,singleton_policy='off',precision=precision)
    b=gr.TDigest.from_array([0.,2.,5.5,10.],weights=[1.,14.,84.,1.],max_size=1,singleton_policy='off',precision=precision)
    assert a.to_bytes()==b.to_bytes()
    examples.append({'precision':precision,'full_state_sha256':hashlib.sha256(a.to_bytes()).hexdigest(),'same_complete_state':True,'capacity':1,'count':a.count,'sum':a.sum,'minimum':a.min,'maximum':a.max,'means':a.means.tolist(),'weights':a.weights.tolist(),'query':5.,'estimate_for_both':a.cdf(5.),'truth_a':.85,'truth_b':.15,'meaning':'Different populations have identical complete compressed state. Query changes alone cannot recover which input was used; this is not proof that capacity32cannot improve.'})
q.atomic_json(work/'results/information-loss.json',{'source_inputs_sha256':source_before,'native_sha256':native_hash,'examples':examples})
print(json.dumps({'profiles':receipt['profiles'],'errors':receipt['errors'],'summary':summary},indent=2))
