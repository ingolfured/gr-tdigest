import hashlib
import importlib
import io
import json
import numpy as np
import polars as pl
import pyarrow as pa
import gr_tdigest as gr
assert pa.__version__=='24.0.0' and np.__version__=='2.5.4' and pl.__version__=='2.0.0'
rows=[]
for dtype in [pl.Float32,pl.Float64]:
 healthy=pl.DataFrame({'x':pl.Series([0.,1.,2.],dtype=dtype)}).select(gr.tdigest('x').alias('d'))
 empty=pl.DataFrame({'x':pl.Series([],dtype=dtype)}).select(gr.tdigest('x').alias('d'))
 frame=pl.concat([healthy,empty]);table=frame.to_arrow()
 sink=pa.BufferOutputStream()
 with pa.ipc.new_stream(sink,table.schema) as writer:writer.write_table(table)
 ipc=pl.from_arrow(pa.ipc.open_stream(sink.getvalue()).read_all())
 buf=io.BytesIO();frame.write_parquet(buf);parquet=pl.read_parquet(io.BytesIO(buf.getvalue()))
 for restored in [ipc,parquet]:
  assert restored.schema==frame.schema
  values=restored.with_columns(pl.Series('probe',[1.,1.])).select(gr.cdf('d',pl.col('probe')).alias('p'))['p'].to_list()
  assert values[0]==.5 and np.isnan(values[1])
  for i in range(2):assert restored.slice(i,1).select(gr.to_bytes('d')).item()==frame.slice(i,1).select(gr.to_bytes('d')).item()
 rows.append({'dtype':str(dtype),'full_state_bytes_preserved':True,'ipc':True,'parquet':True,'healthy_and_empty_isolation':True})
from pathlib import Path
native=Path(importlib.import_module('gr_tdigest._gr_tdigest').__file__)
print(json.dumps({'rows':rows,'numpy':np.__version__,'polars':pl.__version__,'pyarrow':pa.__version__,'python_native_sha256':hashlib.sha256(native.read_bytes()).hexdigest()}))
