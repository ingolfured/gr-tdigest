import base64, hashlib, importlib, json, os, pathlib, subprocess
import numpy as np
import polars as pl
import pyarrow as pa
import gr_tdigest as gr
base=pathlib.Path(__file__).resolve().parent
jar=base/'artifacts-v3/gr-tdigest-0.2.5-dev2026102003.jar'
jdk=pathlib.Path(os.environ['JAVA_HOME'])
source=base/'CrossArtifact.java'; classes=base/'cross-artifact-classes-v3';classes.mkdir(exist_ok=True)
source.write_text("""import gr.tdigest.TDigest;import java.util.*;
public class CrossArtifact {
 public static void main(String[] args) {
  TDigest d=args[0].equals("restore") ? TDigest.fromBytes(Base64.getDecoder().decode(args[1])) :
   TDigest.builder().maxSize(1000).precision(TDigest.Precision.valueOf(args[0])).buildWeighted(new double[]{0,0,1,5,10},new double[]{.25,.75,2,3,4});
  try {System.out.println(Base64.getEncoder().encodeToString(d.toBytes())+"|"+
    Arrays.toString(d.cdf(new double[]{-1,0,.5,1,3,5,10,11}))+"|"+
    Arrays.toString(d.quantile(new double[]{0,.1,.5,.9,1})));}finally{d.close();}
 }
}
""")
subprocess.run([str(jdk/'bin/javac'),'--release','11','-cp',str(jar),'-d',str(classes),str(source)],check=True)
rows=[]
for precision in ('f32','f64'):
 d=gr.TDigest.from_array([0.,0.,1.,5.,10.],weights=[.25,.75,2.,3.,4.],precision=precision,max_size=1000)
 for mode in ('construct','restore'):
  command=[str(jdk/'bin/java'),'-cp',str(jar)+os.pathsep+str(classes),'CrossArtifact']+([precision.upper()] if mode=='construct' else ['restore',base64.b64encode(d.to_bytes()).decode()])
  payload,cdf,quantile=subprocess.check_output(command,cwd='/tmp',text=True).strip().split('|')
  blob=base64.b64decode(payload); restored=gr.TDigest.from_bytes(blob)
  assert blob==d.to_bytes()
  np.testing.assert_allclose(json.loads(cdf),d.cdf([-1,0,.5,1,3,5,10,11]),rtol=0,atol=1e-12)
  np.testing.assert_allclose(json.loads(quantile),d.quantile([0,.1,.5,.9,1]),rtol=0,atol=1e-12)
  rows.append(dict(precision=precision,path=mode,byte_identity=True,cdf_and_quantiles=True))
 for dtype in (pl.Float32,pl.Float64):
  healthy=pl.DataFrame({'x':pl.Series([0.,1.,2.],dtype=dtype)}).select(gr.tdigest('x').alias('d'))
  empty=pl.DataFrame({'x':pl.Series([],dtype=dtype)}).select(gr.tdigest('x').alias('d'))
  frame=pl.concat([healthy,empty]); restored=pl.from_arrow(frame.to_arrow()); assert restored.schema==frame.schema
  probes=restored.with_columns(pl.Series('probe',[1.,1.])).select(gr.cdf('d',pl.col('probe')).alias('p'))['p'].to_list()
  assert probes[0]==.5 and np.isnan(probes[1])
  path=base/('frame-'+str(dtype)+'.parquet');frame.write_parquet(path);loaded=pl.read_parquet(path);assert loaded.schema==frame.schema
rows.append(dict(pyarrow=pa.__version__,polars=pl.__version__,arrow_and_parquet_full_struct_roundtrip=True))
result=dict(rows=rows,numpy=np.__version__,python_native_sha256=hashlib.sha256(pathlib.Path(importlib.import_module('gr_tdigest._gr_tdigest').__file__).read_bytes()).hexdigest(),jar_sha256=hashlib.sha256(jar.read_bytes()).hexdigest())
(base/'results/installed-extra-v3.json').write_text(json.dumps(result,indent=2)+'\n');print('exact wheel/JAR cross-language and PyArrow24 PASS')
