"""Bounded exact-wheel metadata, typing, upgrade/rollback and import ownership."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
old=work.parent/'candidate-20261020'
wheel=work/'artifacts-v3/gr_tdigest-0.2.5.dev2026102003-cp310-abi3-manylinux_2_28_x86_64.whl'
baseline=old/'comparison-baseline-artifact/gr_tdigest-0.2.4-cp310-abi3-manylinux_2_28_x86_64.whl'
record={'source_sha':'60b295140d5eed81df24a8aed05f89767646c7d8','canonical_wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'baseline_wheel_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'baseline_scope':'public source-built 0.2.4 comparison wheel, not private consumer 0.1.9/0.1.11 binaries','commands':[],'steps':[]}
def run(name,cmd):
 r=subprocess.run([str(c) for c in cmd],cwd=work,env=os.environ,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=work/'logs'/f'v3-{name}.log';log.write_text(r.stdout)
 record['commands'].append({'name':name,'command':[str(c) for c in cmd],'cwd':str(work),'exit_code':r.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 assert r.returncode==0,r.stdout[-3000:]
 return r.stdout
qa=work/'artifact-qa-v3'
consumer=work/'typing_consumer_v3.py';shutil.copyfile(old/'typing_consumer.py',consumer)
run('installed-typing',[root/'.venv/bin/mypy','--no-incremental','--follow-imports=silent','--python-executable',qa/'bin/python',consumer])
own=work/'ownership-python-v3-verified'
run('ownership-env',['uv','venv','--offline','--python','3.12',own])
python=own/'bin/python'
run('ownership-deps',['uv','pip','install','--offline','--python',python,'numpy==2.5.4','polars==2.0.0'])
probe='''import hashlib,importlib.metadata as md,json
import gr_tdigest,gr_tdigest._gr_tdigest as native,tdigest_rs
assert gr_tdigest.TDigest.from_array([0.,1.,2.]).median()==1.
assert tdigest_rs.TDigest.__module__=='tdigest_rs.lib'
owners={name:md.packages_distributions().get(name,[]) for name in ('gr_tdigest','tdigest_rs')}
assert all(v==['gr-tdigest'] for v in owners.values()),owners
print(json.dumps({'version':md.version('gr-tdigest'),'native_sha256':hashlib.sha256(open(native.__file__,'rb').read()).hexdigest(),'owners':owners,'original_class':tdigest_rs.TDigest.__module__}))
'''
for name,selected,version in [('baseline',baseline,'0.2.4'),('upgrade',wheel,'0.2.5.dev2026102003'),('rollback',baseline,'0.2.4'),('candidate-reinstall',wheel,'0.2.5.dev2026102003')]:
 run('ownership-'+name,['uv','pip','install','--offline','--python',python,'--no-deps','--reinstall',selected])
 row=json.loads(run('ownership-'+name+'-probe',[python,'-I','-c',probe]));assert row['version']==version
 if selected==wheel:assert row['native_sha256']=='f89b96ebf0d72adee3699599416a1c4e0daeb988921502dfaee6797052bdada6'
 record['steps'].append({'name':name,**row})
run('ownership-uninstall',['uv','pip','uninstall','--python',python,'gr-tdigest'])
run('ownership-uninstall-probe',[python,'-I','-c',"import importlib.util;assert importlib.util.find_spec('gr_tdigest') is None;assert importlib.util.find_spec('tdigest_rs') is None"])
record.update(status='PASS',uninstall_removes_both_imports=True,dependencies='NumPy2.5.4/Polars2.0.0 from staged uv cache; package swaps --no-deps; this probes ownership/import migration, not private binary compatibility')
(work/'results/python-extras-v3.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['status'])
