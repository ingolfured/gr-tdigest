"""Exact-JAR consumers against a controlled, authenticated, staged-only repository."""
import base64
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
from urllib.parse import unquote, urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError

work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
old=work.parent/'candidate-20261020'
version='0.2.5-dev2026102003'
source='60b295140d5eed81df24a8aed05f89767646c7d8'
jar=work/'artifacts-v3'/f'gr-tdigest-{version}.jar'
jarhash=hashlib.sha256(jar.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
fixture=work/'maven-fixture-v3'
dest=fixture/'gr/tdigest/gr-tdigest'/version
dest.mkdir(parents=True,exist_ok=True)
shutil.copyfile(jar,dest/jar.name)
(dest/f'gr-tdigest-{version}.pom').write_text(f'<project><modelVersion>4.0.0</modelVersion><groupId>gr.tdigest</groupId><artifactId>gr-tdigest</artifactId><version>{version}</version></project>\n')
expected='Basic '+base64.b64encode(b'fixture:fixture-password').decode()
requests=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_HEAD(self):self.answer(False)
 def do_GET(self):self.answer(True)
 def answer(self,body):
  path=unquote(urlsplit(self.path).path)
  if self.headers.get('Authorization')!=expected:
   requests.append({'path':path,'status':401})
   self.send_response(401);self.send_header('WWW-Authenticate','Basic realm="Artifactory Realm"');self.end_headers();return
  relative=path.removeprefix('/maven/')
  if not path.startswith('/maven/') or '..' in Path(relative).parts:
   self.send_error(400);return
  file=fixture/relative
  if not file.is_file():file=old/'maven-fixture'/relative
  if not file.is_file():
   requests.append({'path':path,'status':404});self.send_error(404);return
  data=file.read_bytes()
  requests.append({'path':path,'status':200,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
  self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers()
  if body:self.wfile.write(data)
server=ThreadingHTTPServer(('127.0.0.1',39147),Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
url='http://127.0.0.1:39147/maven'
record={'source_sha':source,'jar_sha256':jarhash,'kind':'bounded standalone Scala/Kotlin; no Spark or private repository qualification','repository':url,'repository_inputs':'controlled fixture credentials; staged public dependencies and exact candidate JAR only; no external proxy/fallback','commands':[],'status':'RUNNING'}
def save():
 p=work/'results/languages-v3.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(record,indent=2)+'\n');os.replace(tmp,p)
def run(name,cmd,cwd,env,should_pass=True):
 print(name,flush=True)
 result=subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=work/'logs'/f'v3-{name}.log';log.write_text(result.stdout)
 entry={'name':name,'command':[str(x) for x in cmd],'cwd':str(cwd),'exit_code':result.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 record['commands'].append(entry);save()
 assert (result.returncode==0)==should_pass,result.stdout[-3000:]
 if should_pass:
  marker='SCALA_CONSUMER_OK' if 'scala' in name else 'KOTLIN_CONSUMER_OK'
  assert marker in result.stdout and version in result.stdout
  loaded=re.search(r'jar=(file:[^;\s]+)',result.stdout)
  assert loaded,result.stdout[-1500:]
  path=Path(unquote(urlsplit(loaded.group(1)).path))
  if not path.exists():
   candidates=re.findall(r'Attributed\(([^\n]+?gr-tdigest-'+re.escape(version)+r'\.jar)\)',result.stdout)
   assert len(candidates)==1,candidates
   path=Path(candidates[0])
   entry['runtime_jar_path']='sbt temporary background-job copy; removed after execution'
  assert hashlib.sha256(path.read_bytes()).hexdigest()==jarhash
  assert '68b81960d52e11be245049a359e2e0787274dbe5595a07b9e5f11b5369f0047d' in result.stdout
  entry['resolved_jar_sha256']=jarhash
  entry['resolved_jar_path']=str(path)
 save()
 return result.stdout

env=os.environ.copy()
env.update(TDIGEST_MAVEN_REPOSITORY_URL=url,TDIGEST_MAVEN_USERNAME='fixture',TDIGEST_MAVEN_PASSWORD='fixture-password',TDIGEST_MAVEN_REALM='Artifactory Realm')
jdk11=work.parent/'followup-20261020/toolchains/jdk-5c3f68887c325d36d852ba534303e1f5f1f5cae7d6cc1e951d73e0d8e98a058d/jdk-11.0.32.1+1'
env['TDIGEST_RUNTIME_JAVA_HOME']=str(jdk11)
scala=root/'bindings/java/examples/scala'
kotlin=root/'bindings/java/examples/kotlin'
scala_cmd=[Path(env['JAVA_HOME'])/'bin/java','-Xmx1g','-XX:ActiveProcessorCount=4','-Dsbt.task.cpus=2','-Dsbt.supershell=false','-Dsbt.override.build.repos=true',f'-Dsbt.repository.config={old}/sbt-repositories',f'-Dsbt.boot.credentials={old}/sbt-fixture.credentials',f'-Dsbt.boot.directory={old}/sbt-boot',f'-Dtdigest.version={version}','-jar',old/'sbt-launch-1.12.11.jar']
kotlin_cmd=[root/'bindings/java/gradlew','--no-daemon','--console=plain','--init-script',old/'kotlin-runtime.init.gradle','-p',kotlin,f'-PtdigestVersion={version}']
try:
 run('scala-authenticated',scala_cmd+['clean','run','show Compile / dependencyClasspath'],scala,env)
 run('kotlin-authenticated',kotlin_cmd+['clean','run'],root,env)
 bad=env.copy();bad.update(TDIGEST_MAVEN_PASSWORD='deliberately-wrong',GRADLE_USER_HOME=str(work/'negative-gradle-cache-v3'))
 output=run('maven-bad-credentials',kotlin_cmd+['run'],root,bad,False)
 assert '401' in output and '127.0.0.1:39147' in output
 record['negative_credentials']='fresh Gradle cache rejected with HTTP401; configured repository has no fallback'
 server.shutdown();server.server_close();thread.join()
 record['offline_repository_stopped']=True
 run('scala-offline',scala_cmd+['set offline := true','clean','run','show Compile / dependencyClasspath'],scala,env)
 run('kotlin-offline',kotlin_cmd+['--offline','clean','run'],root,env)
 assert any(r.get('sha256')==jarhash for r in requests)
 assert any(r['status']==401 for r in requests)
 record['status']='PASS'
finally:
 server.shutdown();server.server_close()
 record['requests']=requests;save()
print(record['status'],flush=True)
