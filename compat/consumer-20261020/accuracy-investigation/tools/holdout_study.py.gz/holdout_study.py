"""Fresh deterministic holdout shapes; no RNG or frozen-reference changes."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from statistics import NormalDist
import sys
import numpy as np
import gr_tdigest as gr
import gr_tdigest._gr_tdigest as native

work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
spec=importlib.util.spec_from_file_location('quality_holdout',root/'scripts/quality_suite.py')
q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
n=8192
u=[(i+.5)/n for i in range(n)]
z=[NormalDist().inv_cdf(x) for x in u]
shapes={f'separated_{gap}':[a+(-gap if i%2 else gap) for i,a in enumerate(z)] for gap in [3,12,40]}
shapes.update({
    'uneven_three_clusters':[(-20+u[i]) if i<int(n*.8) else (u[i] if i<int(n*.95) else 20+u[i]) for i in range(n)],
    'rare_far_tail':[z[i] if i<int(n*.999) else 1e9 for i in range(n)],
    'wide_signed_axis':[(-1 if i%2 else 1)*10**(60*u[i]-30) for i in range(n)],
    'near_equal':[1+1e-12*x for x in u],
    'small_signed_values':[(2*x-1)*1e-30 for x in u],
    'sparse_repeated_levels':[float((i*17)%37)**3 for i in range(n)],
    'alternating_drift':[float((i//205)**2)+(-100 if i%2 else 100) for i in range(n)],
    'extreme_point_pile':[0. if i<int(n*.985) else 10**(20*u[i]) for i in range(n)],
    'folded_bell':[abs(a) for a in z],
})
# Fixed coprime permutation changes shard composition without an RNG claim.
shapes={name:[values[(i*4093)%n] for i in range(n)] for name,values in shapes.items()}
module=Path(native.__file__)
receipt={'kind':'additional diagnostic holdouts, not independent statistical trials or new acceptance gates','source_inputs_sha256':q.source_hashes(),'native_sha256':q.sha(module),'runner_sha256':q.sha(Path(__file__)),'generator':'8192stratified/deterministic values per shape; fixed4093coprime permutation; no RNG','rows':[],'input_status':'NOT_VERIFIED'}
for name,raw in shapes.items():
    for precision in ['f32','f64']:
        values=np.array(raw,dtype=np.float32 if precision=='f32' else np.float64)
        exact=q.Exact(values.tolist())
        for scale in ['k2','quad']:
            q.PROTOCOL['modern']['scale']=scale
            for cap in [32,200,1000]:
                for order in ['natural','reverse']:
                    data=values if order=='natural' else values[::-1].copy()
                    for route in ['bulk','left40','balanced40']:
                        row={'id':f'{name}/{precision}/{scale}/{cap}/{order}/{route}','dataset':name,'precision':precision,'scale':scale,'max_size':cap,'order':order,'path':route,'input_sha256':hashlib.sha256(data.tobytes()).hexdigest()}
                        try:
                            d=q.build(data,precision,cap,'modern',route)
                            row['modern']=q.score(d,exact,True)
                            row['state']={**q.invariants(d,data,precision,True),'centroids':len(d),'wire_bytes':len(d.to_bytes())}
                            bound=.1 if cap==32 else .05
                            row['diagnostic_envelope_failures']=[k for k in ['rank_max','cdf_max'] if row['modern'][k]>bound]
                        except Exception as e: row['error']=f'{type(e).__name__}: {e}'
                        receipt['rows'].append(row)
    q.atomic_json(work/'results/holdouts.json',receipt)
    print(name,'completed',flush=True)
q.verify_inputs_unchanged(receipt,module)
receipt['input_status']='UNCHANGED'
receipt['summary']={}
for scale in ['k2','quad']:
    for cap in [32,200,1000]:
        rows=[r for r in receipt['rows'] if r['scale']==scale and r['max_size']==cap]
        receipt['summary'][f'{scale}/{cap}']={'profiles':len(rows),'errors':sum('error' in r for r in rows),'envelope_failed_profiles':sum(bool(r.get('diagnostic_envelope_failures')) for r in rows),'worst_errors':{m:max(r['modern'][m] for r in rows if 'modern' in r) for m in q.GATED}}
q.atomic_json(work/'results/holdouts.json',receipt)
print(json.dumps(receipt['summary'],indent=2))
