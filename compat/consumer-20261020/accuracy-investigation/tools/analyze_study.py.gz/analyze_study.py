import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
from statistics import median
import sys
work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
spec=importlib.util.spec_from_file_location('quality_analysis',root/'scripts/quality_suite.py')
q=importlib.util.module_from_spec(spec);sys.modules[spec.name]=q;spec.loader.exec_module(q)
frozen=q.read_json(root/'tests/quality/baseline-extended.json.gz')
reference={r['id']:r for r in frozen['rows']}
trials=json.loads((work/'results/trials.json').read_text())
summary={'numerical_base_sha':trials['base_sha'],'original_engine_unchanged':True,'thresholds_and_frozen_references_changed':False,'trials':[]}
for trial in trials['trials']:
    report=json.loads((work/'results'/trial['id']/'results.json').read_text())
    assert len(report['rows'])==756 and report['input_status']=='UNCHANGED'
    metrics={m:[] for m in q.GATED};regressed=set();other=[]
    for row in report['rows']:
        if 'error' in row and not row['error'].startswith('AssertionError: quality regression:'):other.append(row['id'])
        if 'modern' not in row:continue
        for metric in q.GATED:
            before=reference[row['id']]['modern'][metric];after=row['modern'][metric]
            if after>q.regression_limit(metric,before,row['n'],row['precision']):
                regressed.add(row['id']);metrics[metric].append({'id':row['id'],'before':before,'after':after,'increase':after-before})
    summary['trials'].append({'id':trial['id'],'regressed_profiles':len(regressed),'other_errors':other,'diagnostic_failed_profiles':report['summary']['all']['accuracy_limit_failures'],'metrics':{m:{'regressed_profiles':len(v),'worst_increases':sorted(v,key=lambda r:r['increase'],reverse=True)[:3]} for m,v in metrics.items()},'decision':'CONTROL' if trial['id']=='control' else 'REJECTED_NOT_SHIPPED'})
new=json.loads((work/'results/reproducible-budgets.json').read_text())
assert new['measurement_status']=='COMPLETED' and new['input_status']=='UNCHANGED' and len(new['rows'])==4140
assert all('error' not in r for r in new['rows'])
summary['diagnostic_study']={'profiles':4140,'errors':0,'accuracy_status':new['accuracy_status'],'groups':new['summary'],'diagnostic_failed_profiles':sum(bool(r['diagnostic_failures']) for r in new['rows'])}
summary['payload_ratios_1000_to_200']={}
for precision in ['f32','f64']:
    rows=[r for r in new['rows'] if r['cohort']=='capacity' and r['scale']=='k2' and r['precision']==precision and r['max_size'] in [200,1000]]
    by={(r['dataset'],r['order'],r['path'],r['max_size']):r for r in rows}
    ratios=[r['modern_state']['wire_bytes']/by[(r['dataset'],r['order'],r['path'],200)]['modern_state']['wire_bytes'] for r in rows if r['max_size']==1000]
    summary['payload_ratios_1000_to_200'][precision]={'minimum':min(ratios),'median':median(ratios),'maximum':max(ratios),'meaning':'same-case saved byte length, not RSS or allocator/temporary footprint'}
summary['limitations']=['No trial removed the failures without new frozen-reference regressions.','Quad passes established size32diagnostics but fails12additional profiles, and worsens tails.','K2size64also has8established diagnostic failures; lower-capacity failures remain explicit.','Passing the rank/CDF envelope is not acceptance of value errors or an approved excluded domain.','Extreme dynamic range has very large normalized/absolute value errors despite small rank error; type7reference differs from exact-point quantile conventions.','Profile counts share data and are not independent statistical trials.','Only the measured source/native/inputs are covered; original has no CDF and none is fabricated.']
summary['files']={str(p.relative_to(work)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in [work/'results/trials.json',work/'results/reproducible-budgets.json',work/'results/merge-traces.json',work/'results/information-loss.json',work/'results/study-postprocess-repair.json']}
(work/'results/analysis.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'trials':[(r['id'],r['regressed_profiles'],r['diagnostic_failed_profiles']) for r in summary['trials']],'diagnostic_profiles':4140,'diagnostic_failed_profiles':summary['diagnostic_study']['diagnostic_failed_profiles'],'payload_ratios':summary['payload_ratios_1000_to_200']},indent=2))
