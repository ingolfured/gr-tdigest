import gr.tdigest.TDigest;
public class JvmProbe {
 public static void main(String[] args) {
  System.out.println(TDigest.runtimeInfo());
  if (args.length > 0 && args[0].equals("pressure")) {
   double[] values = new double[128];
   for (int i=0;i<values.length;i++) values[i] = (i*17)%1009;
   for (int round=0;round<8;round++) {
    TDigest[] live = new TDigest[4096];
    try {
     for (int i=0;i<live.length;i++) {
      live[i] = TDigest.builder().maxSize(200).build(values);
      if (i%64==0) try (TDigest restored=TDigest.fromBytes(live[i].toBytes())) {
       if (restored.median()!=live[i].median()) throw new AssertionError();
      }
     }
     System.gc();
     for (TDigest d:live) if (!Double.isFinite(d.median())) throw new AssertionError();
    } finally {for(TDigest d:live) if(d!=null) d.close();}
   }
   System.out.println("BOUNDED_PRESSURE_OK digests=32768 peak_live=4096 observations=4194304");
  } else try (TDigest d = TDigest.builder().buildWeighted(new double[]{0,10},new double[]{9,1})) {
   if (d.median()!=0) throw new AssertionError();
   System.out.println("JVM_PAYLOAD_OK");
  }
 }
}
