"""Bounded qualification of exact review artifacts from one frozen source."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from zipfile import ZipFile

work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
old=work.parent/'candidate-20261020'
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert source=='60b295140d5eed81df24a8aed05f89767646c7d8'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
art=work/'artifacts-v3';version='0.2.5-dev2026102003'
wheel=art/'gr_tdigest-0.2.5.dev2026102003-cp310-abi3-manylinux_2_28_x86_64.whl'
jar=art/f'gr-tdigest-{version}.jar'
baseenv=os.environ.copy()
record={'source_sha':source,'kind':'bounded review-artifact qualification; numerical acceptance remains FAIL','commands':[],'status':'RUNNING'}
def save():
    target=work/'results/artifact-qualification-v3.json';tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');os.replace(tmp,target)
def run(name,cmd,cwd=work,env=None,allowed=(0,)):
    print(name,flush=True)
    result=subprocess.run([str(c) for c in cmd],cwd=cwd,env=env or baseenv,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=work/'logs'/f'v3-artifact-{name}.log';log.write_text(result.stdout)
    record['commands'].append({'name':name,'command':[str(c) for c in cmd],'cwd':str(cwd),'exit_code':result.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save()
    if result.returncode not in allowed:raise RuntimeError(f'{name} failed: {log}')
    return result.stdout
save()
# Verify a new isolated installation, never the editable checkout or an old wheel.
qa=work/'artifact-qa-v3'
run('qa-env',['uv','venv','--python','3.12',qa])
python=qa/'bin/python'
run('qa-install',['uv','pip','install','--python',python,'--only-binary',':all:','numpy==2.5.4','scipy==1.18.1','pytest==9.1.1','polars==2.0.0','pyarrow==24.0.0',wheel])
run('installed-quality',[python,'-I',root/'scripts/quality_suite.py','--mode','extended','--baseline',root/'tests/quality/baseline-extended.json.gz','--known-failures',root/'tests/quality/known-limits.json','--output',work/'results/installed-quality-v3'])
run('installed-budgets',[python,'-I',root/'scripts/quality_budgets.py','--output',work/'results/installed-budgets-v3.json'],allowed=(1,))
budgets=json.loads((work/'results/installed-budgets-v3.json').read_text())
assert budgets['measurement_status']=='COMPLETED' and budgets['input_status']=='UNCHANGED'
assert len(budgets['rows'])==4140 and not any('error' in r for r in budgets['rows'])
with ZipFile(wheel) as archive:
    assert budgets['native_sha256']==hashlib.sha256(archive.read('gr_tdigest/_gr_tdigest.abi3.so')).hexdigest()
# Independent binding native payloads share this exact source, not necessarily bytes.
env=baseenv.copy();env['CARGO_TARGET_DIR']='/home/ingo/.cache/gr-tdigest-20261020/jni-target'
run('jni-build',[root/'.venv/bin/cargo-zigbuild','zigbuild','--release','--locked','--offline','--features','java','--lib','--target','x86_64-unknown-linux-gnu.2.17'],root,env)
native=Path(env['CARGO_TARGET_DIR'])/'x86_64-unknown-linux-gnu/release/libgr_tdigest.so'
so=art/'libgr_tdigest-jni-glibc217.so';shutil.copyfile(native,so)
env.update(TDIGEST_NATIVE_FILE=str(so),TDIGEST_SOURCE_SHA=source)
run('jar-build',[root/'bindings/java/gradlew','--no-daemon','--console=plain','--offline','-p',root/'bindings/java','clean','jar','verifyJava11Bytecode'],root,env)
shutil.copyfile(root/'bindings/java/build/libs'/jar.name,jar)
console=work/'junit-platform-console-standalone-1.11.4.jar'
shutil.copyfile(old/console.name,console)
classes=work/'jvm-test-classes-v3';classes.mkdir()
sources=sorted((root/'bindings/java/src/test/java').rglob('*.java'))
run('junit-compile',[Path(baseenv['JAVA_HOME'])/'bin/javac','--release','11','-cp',f'{jar}:{console}','-d',classes,*sources])
jdk11=work.parent/'followup-20261020/toolchains/jdk-5c3f68887c325d36d852ba534303e1f5f1f5cae7d6cc1e951d73e0d8e98a058d/jdk-11.0.32.1+1'
for name,jdk in [('java11',jdk11),('java17',Path(baseenv['JAVA_HOME'])),('java21',Path('/usr/lib/jvm/java-21-openjdk'))]:
    isolated=baseenv.copy();isolated['PATH']='/nonexistent'
    output=run(name,[jdk/'bin/java','-Xmx256m','-XX:ActiveProcessorCount=4','-jar',console,'execute','--disable-ansi-colors','--class-path',f'{jar}:{classes}','--scan-classpath','--fail-if-no-tests','--details','summary'],env=isolated)
    assert re.search(r'20 tests successful',output),output[-1200:]
with ZipFile(wheel) as archive:
    py_native=art/'libgr_tdigest-python-glibc228.so';py_native.write_bytes(archive.read('gr_tdigest/_gr_tdigest.abi3.so'))
with ZipFile(jar) as archive:
    record['jar_manifest']=archive.read('META-INF/MANIFEST.MF').decode()
    assert source in record['jar_manifest']
    assert archive.read('META-INF/native/linux-x86_64/libgr_tdigest.so')==so.read_bytes()
    assert all(int.from_bytes(archive.read(n)[6:8],'big')==55 for n in archive.namelist() if n.endswith('.class'))
record['symbols']={}
for name,native,floor in [('python',py_native,(2,28)),('jni',so,(2,17))]:
    text=run(name+'-symbols',['readelf','--version-info',native])
    versions=sorted({tuple(map(int,x.split('.'))) for x in re.findall(r'Name: GLIBC_([0-9.]+)',text)})
    assert versions[-1]<=floor,versions
    record['symbols'][name]={'maximum_required_glibc':'.'.join(map(str,versions[-1])),'sha256':hashlib.sha256(native.read_bytes()).hexdigest()}
# Stage public tests for execution with no source checkout in the minimum-ABI images.
sys.path.insert(0,str(root/'scripts'))
from test_legacy_wheel import stage_compatibility_tests
from test_python_support import MODERN_TESTS
floor=work/'floor-tests-v3';floor.mkdir()
stage_compatibility_tests(root,floor)
modern=floor/'modern';modern.mkdir()
for relative in MODERN_TESTS:shutil.copyfile(root/relative,modern/Path(relative).name)
podman=['podman','--root','/home/ingo/.cache/gr-tdigest-20261020/containers','--runroot','/tmp/gr-tdigest-containers-run','--storage-driver','vfs','--storage-opt','ignore_chown_errors=true']
images={'python':'f63d8d2889fdbb0b12bde4a7879e843b13c1d61f93562d8a41729244536214d9','jni':'8652b9f0cb4c0599575e5a003f5906876e10c1ceb2ab9fe1786712dac14a50cf'}
record['images']=images
for name,image in images.items():
    run(name+'-image',podman+['image','inspect',image])
    output=run(name+'-actual-libc',podman+['run','--rm','--pull','never','--network','none',image,'getconf','GNU_LIBC_VERSION'])
    assert ('2.28' if name=='python' else '2.17') in output
common=podman+['run','--rm','--pull','never','--network','none','-v',f'{work}:{work}:ro','-w','/tmp']
output=run('python-glibc228',common+['-v','/home/ingo/.local/share/uv/python:/home/ingo/.local/share/uv/python:ro','-e','PYTEST_DISABLE_PLUGIN_AUTOLOAD=1','-e','POLARS_MAX_THREADS=4','-e','RAYON_NUM_THREADS=4','-e','OMP_NUM_THREADS=1','-e','OPENBLAS_NUM_THREADS=1',images['python'],python,'-I','-m','pytest','-q','-c','/dev/null','-p','no:cacheprovider','-o','xfail_strict=true',floor])
assert '433 passed' in output,output[-1500:]
output=run('java11-glibc217',common+['-v',f'{jdk11}:/jdk:ro',images['jni'],'/jdk/bin/java','-Xmx256m','-XX:ActiveProcessorCount=4','-jar',console,'execute','--disable-ansi-colors','--class-path',f'{jar}:{classes}','--scan-classpath','--fail-if-no-tests','--details','summary'])
assert re.search(r'20 tests successful',output),output[-1500:]
record['artifacts']={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in art.iterdir() if p.is_file()}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
record['status']='PASS_BOUNDED_CHECKS_NUMERICAL_ACCEPTANCE_STILL_FAIL';save()
print(record['status'],flush=True)
