"""Run small final source/JAR checks serially after workload measurements complete."""
import hashlib,json,os
from pathlib import Path
import shutil,subprocess
work=Path(__file__).resolve().parent;root=work.parent/'gr-tdigest-candidate'
ledger=json.loads((work/'results/performance-v3/ledger.json').read_text());assert len(ledger)==28 and all(x['exit_code']==0 for x in ledger)
source='60b295140d5eed81df24a8aed05f89767646c7d8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
jar=work/'artifacts-v3/gr-tdigest-0.2.5-dev2026102003.jar'
native=work/'artifacts-v3/libgr_tdigest-jni-glibc217.so'
jdk11=work.parent/'followup-20261020/toolchains/jdk-5c3f68887c325d36d852ba534303e1f5f1f5cae7d6cc1e951d73e0d8e98a058d/jdk-11.0.32.1+1'
runtime=work/'jvm-runtime-v3';(runtime/'native').mkdir(parents=True)
shutil.copyfile(native,runtime/'native/libgr_tdigest.so')
(runtime/'extract').mkdir();(runtime/'not-a-directory').write_text('controlled invalid fixture')
record={'source_sha':source,'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'commands':[]}
def run(name,cmd,cwd,expected=0):
 r=subprocess.run([str(x) for x in cmd],cwd=cwd,env=os.environ,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=work/'logs'/f'v3-{name}.log';log.write_text(r.stdout)
 record['commands'].append({'name':name,'command':[str(x) for x in cmd],'cwd':str(cwd),'exit_code':r.returncode,'expected_exit_code':expected,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 assert r.returncode==expected,r.stdout[-2000:]
 return r.stdout
run('bootstrap',['make','java-bootstrap-test'],root)
run('source-guard',['python3','scripts/check_upstream_sources.py'],root)
for name,options,expected in [('bundled',[],0),('relative',['-Dgr.tdigest.native=native/libgr_tdigest.so'],0),('extraction',[f'-Dgr.tdigest.extractDir={runtime}/extract'],0),('bad-override',['-Dgr.tdigest.native=missing.so'],1),('bad-extraction',[f'-Dgr.tdigest.extractDir={runtime}/not-a-directory'],1)]:
 output=run('loader-'+name,[jdk11/'bin/java',*options,'-cp',f'{jar}:{work}/probe-classes-v3','JvmProbe'],runtime,expected)
 if not expected:assert 'JVM_PAYLOAD_OK' in output and '68b81960d52e11be245049a359e2e0787274dbe5595a07b9e5f11b5369f0047d' in output
 else:assert 'UnsatisfiedLinkError' in output
record['status']='PASS'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
(work/'results/final-gates-v3.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['status'])
