"""Run serialized temporary compressor trials; restore tracked source afterwards."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
root=work.parent/'gr-tdigest-candidate'
core=root/'src/tdigest/compressor.rs'
base=(work/'compressor-base.rs').read_text()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='35b0d799a6212399fed32de689609abb880b3e18'
assert core.read_text()==base
python=root/'.venv/bin/python'

def transform(name):
    if name=='control': return base
    old='cap_core::<F>(core, slices.caps.core_cap, d, family)'
    assert base.count(old)==1
    if name=='direct-cap':
        return base.replace(old,'cap_core::<F>(slices.interior.to_vec(), slices.caps.core_cap, d, family)')
    if name=='equal-mass':
        return base.replace(old, '''if slices.interior.len() <= slices.caps.core_cap {
            slices.interior.to_vec()
        } else {
            bucketize_equal_weight(slices.interior, slices.caps.core_cap)
        }''')
    if name=='reverse-scan':
        marker='fn klimit_merge<F: FloatLike + FloatCore>('
        assert base.count(marker)==1
        helper='''fn klimit_merge<F: FloatLike + FloatCore>(
    items: &[Centroid<F>], d: f64, family: ScaleFamily, tol: f64,
) -> Vec<Centroid<F>> {
    let mirror = |c: &Centroid<F>| {
        if c.is_atomic() {
            Centroid::<F>::new_atomic_f64(-c.mean_f64(), c.weight_f64())
        } else {
            Centroid::<F>::new_mixed_f64(-c.mean_f64(), c.weight_f64())
        }
    };
    let reflected: Vec<_> = items.iter().rev().map(mirror).collect();
    let result = klimit_merge_forward(&reflected, d, family, tol);
    result.iter().rev().map(mirror).collect()
}

fn klimit_merge_forward<F: FloatLike + FloatCore>('''
        return base.replace(marker,helper)
    raise ValueError(name)

def save(record):
    p=work/'results/trials.json'; t=p.with_suffix('.tmp')
    t.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');os.replace(t,p)

record={'base_sha':head,'kind':'temporary local development trials; no release/artifact qualification', 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status':'RUNNING','trials':[]}
save(record)
try:
    for name in ['control','direct-cap','equal-mass','reverse-scan']:
        print('START',name,flush=True)
        core.write_text(transform(name))
        subprocess.run(['cargo','fmt','--all'],cwd=root,check=True,stdout=subprocess.DEVNULL)
        patch=subprocess.check_output(['git','diff','HEAD','--','src/tdigest/compressor.rs'],cwd=root)
        patchpath=work/'patches'/f'{name}.patch';patchpath.write_bytes(patch)
        row={'id':name,'base_sha':head,'patch_sha256':hashlib.sha256(patch).hexdigest(),'compressor_sha256':hashlib.sha256(core.read_bytes()).hexdigest()}
        with (work/'logs'/f'{name}-build.log').open('wb') as log:
            build=subprocess.run([str(root/'.venv/bin/maturin'),'develop','--release','-F','python'],cwd=root/'bindings/python',stdout=log,stderr=subprocess.STDOUT)
        row['build_exit']=build.returncode
        if build.returncode:
            record['trials'].append(row);save(record);raise RuntimeError(f'{name}: build failed')
        path=Path(subprocess.check_output([str(python),'-c','import gr_tdigest._gr_tdigest as m;print(m.__file__)'],cwd=root,text=True).strip())
        row['native_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        (work/'results'/f'{name}-native.so.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
        target=work/'results'/name
        command=[str(python),'scripts/quality_suite.py','--mode','extended','--baseline','tests/quality/baseline-extended.json.gz','--known-failures','tests/quality/known-limits.json','--output',str(target)]
        with (work/'logs'/f'{name}-quality.log').open('wb') as log:
            run=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        row['quality_exit']=run.returncode
        result=json.loads((target/'results.json').read_text())
        assert result['input_status']=='UNCHANGED' and result['native_sha256']==row['native_sha256'] and len(result['rows'])==756
        row.update(regression_status=result['regression_status'],accuracy_status=result['accuracy_status'],errors=result['summary']['all']['errors'],envelope_failures=result['summary']['all']['accuracy_limit_failures'])
        record['trials'].append(row);save(record)
        print('DONE',json.dumps(row),flush=True)
finally:
    core.write_text(base)
    record['source_restored']=core.read_text()==base
    record['status']='COMPLETED' if len(record['trials'])==4 and all(t.get('build_exit')==0 for t in record['trials']) else 'INCOMPLETE'
    record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(record)
