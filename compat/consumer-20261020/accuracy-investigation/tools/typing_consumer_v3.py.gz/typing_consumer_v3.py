from gr_tdigest import TDigest, cdf, tdigest, from_bytes
from polars import Expr
import numpy as np

d: TDigest = TDigest.from_array([0.0,10.0],weights=[9.0,1.0],max_size=1000)
probability: float = d.cdf(5.0)
probabilities: list[float] = d.cdf([0.0,10.0])
restored: TDigest = TDigest.from_bytes(d.to_bytes())
expression: Expr = cdf(tdigest("values"),"probes")
decoded: Expr = from_bytes("encoded",precision="f64")
weights: np.ndarray = d.weights
